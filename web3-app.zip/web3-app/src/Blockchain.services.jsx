import Web3 from "web3";
import { setGlobalState, getGlobalState } from "./store";
import abi from "./abis/DominionDAO.json";

const { ethereum } = window;

if (ethereum) {
  window.web3 = new Web3(ethereum);
}

const connectWallet = async () => {
  try {
    if (!ethereum) {
      alert("Please install MetaMask");
      return;
    }

    const accounts = await ethereum.request({
      method: "eth_requestAccounts",
    });

    setGlobalState("connectedAccount", accounts[0].toLowerCase());
  } catch (error) {
    reportError(error);
  } finally {
    window.location.reload();
  }
};

const isWallectConnected = async () => {
  try {
    if (!ethereum) {
      alert("Please install MetaMask");
      return;
    }

    const accounts = await ethereum.request({
      method: "eth_accounts",
    });

    window.ethereum.on("chainChanged", () => {
      window.location.reload();
    });

    window.ethereum.on("accountsChanged", async (newAccounts) => {
      if (newAccounts.length) {
        setGlobalState(
          "connectedAccount",
          newAccounts[0].toLowerCase()
        );
      } else {
        setGlobalState("connectedAccount", "");
      }

      window.location.reload();
    });

    if (accounts.length) {
      setGlobalState("connectedAccount", accounts[0].toLowerCase());
    } else {
      setGlobalState("connectedAccount", "");
      console.log("No accounts found.");
    }
  } catch (error) {
    reportError(error);
  }
};

const getEtheriumContract = async () => {
  const connectedAccount = getGlobalState("connectedAccount");

  if (!connectedAccount) {
    return getGlobalState("contract");
  }

  if (!ethereum) {
    throw new Error("Please install MetaMask");
  }

  const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;

  if (!contractAddress) {
    throw new Error(
      "Missing REACT_APP_CONTRACT_ADDRESS in web3-app/.env"
    );
  }

  if (!Web3.utils.isAddress(contractAddress)) {
    throw new Error("Invalid contract address in web3-app/.env");
  }

  const web3 = new Web3(ethereum);
  const contract = new web3.eth.Contract(abi.abi, contractAddress);

  return contract;
};

const performContribute = async (amount) => {
  try {
    const value = window.web3.utils.toWei(amount.toString(), "ether");
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    await contract.methods.contribute().send({
      from: account,
      value,
    });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const getInfo = async () => {
  try {
    if (!ethereum) {
      alert("Please install MetaMask");
      return;
    }

    const contract = await getEtheriumContract();
    const connectedAccount = getGlobalState("connectedAccount");

    if (!connectedAccount || !contract) return;

    const isStakeholder = await contract.methods
      .isStakeholder()
      .call({ from: connectedAccount });

    const balance = await contract.methods.daoBalance().call();

    const mybalance = await contract.methods
      .getBalance()
      .call({ from: connectedAccount });

    setGlobalState(
      "balance",
      window.web3.utils.fromWei(balance.toString(), "ether")
    );

    setGlobalState(
      "mybalance",
      window.web3.utils.fromWei(mybalance.toString(), "ether")
    );

    setGlobalState("isStakeholder", isStakeholder);
  } catch (error) {
    reportError(error);
  }
};

const raiseProposal = async ({
  title,
  description,
  beneficiary,
  amount,
}) => {
  try {
    const value = window.web3.utils.toWei(amount.toString(), "ether");
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    await contract.methods
      .createProposal(title, description, beneficiary, value)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const getProposals = async () => {
  try {
    if (!ethereum) {
      alert("Please install MetaMask");
      return;
    }

    const contract = await getEtheriumContract();
    if (!contract) return;

    const proposals = await contract.methods.getProposals().call();

    setGlobalState("proposals", structuredProposals(proposals));
  } catch (error) {
    reportError(error);
  }
};

const structuredProposals = (proposals) => {
  return proposals
    .map((proposal) => ({
      id: proposal.id,
      amount: window.web3.utils.fromWei(
        proposal.amount.toString(),
        "ether"
      ),
      title: proposal.title,
      description: proposal.description,
      paid: proposal.paid,
      passed: proposal.passed,
      proposer: proposal.proposer,
      upvotes: Number(proposal.upvotes),
      downvotes: Number(proposal.downvotes),
      beneficiary: proposal.beneficiary,
      executor: proposal.executor,
      duration: proposal.duration,
    }))
    .reverse();
};

const getProposal = async (id) => {
  try {
    const proposals = getGlobalState("proposals");
    return proposals.find((proposal) => proposal.id == id);
  } catch (error) {
    reportError(error);
    return undefined;
  }
};

const voteOnProposal = async (proposalId, supported) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    await contract.methods
      .performVote(proposalId, supported)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const listVoters = async (id) => {
  try {
    const contract = await getEtheriumContract();
    return await contract.methods.getVotesOf(id).call();
  } catch (error) {
    reportError(error);
    return [];
  }
};

const payoutBeneficiary = async (id) => {
  try {
    const contract = await getEtheriumContract();
    const account = getGlobalState("connectedAccount");

    await contract.methods
      .payBeneficiary(id)
      .send({ from: account });

    window.location.reload();
  } catch (error) {
    reportError(error);
    return error;
  }
};

const reportError = (error) => {
  console.error("Blockchain error:", error);
};

export {
  isWallectConnected,
  connectWallet,
  performContribute,
  getInfo,
  raiseProposal,
  getProposals,
  getProposal,
  voteOnProposal,
  listVoters,
  payoutBeneficiary,
};