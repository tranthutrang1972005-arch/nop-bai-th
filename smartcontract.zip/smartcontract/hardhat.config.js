require("@nomiclabs/hardhat-waffle");
const fs = require("fs");
const path = require("path");

// Đọc file .env
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([\w.-]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) {
      process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, "");
    }
  }
}

let PRIVATE_KEY = (process.env.PRIVATE_KEY || "").trim();
if (PRIVATE_KEY && !PRIVATE_KEY.startsWith("0x")) PRIVATE_KEY = "0x" + PRIVATE_KEY;
const hasValidKey = /^0x[0-9a-fA-F]{64}$/.test(PRIVATE_KEY);

module.exports = {
  solidity: {
    compilers: [{ version: "0.7.3" }, { version: "0.8.7" }, { version: "0.8.28" }],
  },
  networks: {
    sepolia: {
      url: process.env.SEPOLIA_RPC_URL || "https://ethereum-sepolia-rpc.publicnode.com",
      chainId: 11155111,
      accounts: hasValidKey ? [PRIVATE_KEY] : [],
    },
  },
};